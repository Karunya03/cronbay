<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

<h1>latest job</h1>

<h2> active jobs </h2>

<a href="add_jobs.php">Add jobs</a>
</body>
</html>